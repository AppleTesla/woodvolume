# Creating a Photogrammetry Command-Line App

Generate 3D objects from images using RealityKit Object Capture.

## Overview

- Note: This sample code project is associated with WWDC21 session [10076: Create 3D Models with Object Capture](https://developer.apple.com/wwdc21/10076/).
